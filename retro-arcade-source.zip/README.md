# NOM · Pocket Arcade

An original-game browser port of the supplied `NOM.jar` (Living Mobile 1.0.25).

The same page also offers `nom2.jar`: **NOM2 FREE RUNNER 1.0.42**, the supplied overseas Nokia E62 edition. Use the game selector above the player, or open `?game=nom2` directly. Each selection loads its own ahead-of-time compiled JavaScript and embedded resources. A full document navigation when switching titles cleanly disposes of the previous game loop and audio. Original NOM saves retain their existing keys; NOM 2 saves use a separate namespace. NOM uses 176×208, NOM 2 uses 320×240, including fullscreen fit and rotation.

Both builds retain their original game lifecycle. The browser adapter does not enable retired carrier network services. NOM 2's network leaderboard, space mail and external store are unavailable offline. Its legacy device key codes are mapped from the shared screen/keyboard controls.

## Architecture

The build normalizes obfuscated field identifiers, then uses TeaVM 0.12.3 to ahead-of-time compile the original game bytecode into ECMAScript (`dist/nom.js`). No JVM, CheerpJ, WebAssembly or bytecode interpreter runs in the browser. This is a compiled port, not a handwritten reconstruction of the gameplay.

Only the APIs used by this particular game are implemented in `src/main/java/javax/microedition/`: Canvas 2D rendering, keyboard/pointer input, browser storage and browser audio. The original proprietary PZX sprite decoding, NOD stage loading, collision, animation and game loop execute as generated JavaScript. `host.js` connects the generated code to standard browser APIs.

Original WAV effects play as WAV. Original MIDI event timing and pitches play through a small Web Audio triangle-wave synthesizer; its timbre differs from original phone hardware. The original handset network links and vibration are disabled. This port uses the supplied overseas edition and does not add Korean localization.

The `lib/` files and generated game assets are from the user-supplied game. Original copyright remains with its owners. TeaVM is Apache-2.0. The bridge/page source is separate from the original game.

## Run locally

Serve `dist/` over HTTP, for example:

```powershell
python -m http.server 8767 --bind 127.0.0.1 --directory dist
```

Open http://127.0.0.1:8767/ and click **게임 시작**. No Java installation is needed to play.

## Build

Requires JDK 17+, Maven 3.9+, Python 3. The first build downloads Maven dependencies.

```powershell
./tools/build.ps1
```

For this workspace the script can reuse the portable build tools under ignored `analysis/`. On another machine set `JAVA_HOME` and put `mvn` on PATH. `tools/PatchJar.java` performs descriptor-aware field renaming and reroutes resource lookups to the embedded resource map. It does not change stage or gameplay logic. Source `lib/NOM.jar` stays unchanged.

## Controls

- Arrows: menu movement
- Enter, Space, 5: confirm / action / jump
- F1: left soft key
- Escape or F2: right soft key
- On-screen buttons: equivalent pointer/touch controls
- Toolbar: rotate display, mute, full screen

Save data is browser-local and origin-specific. Restarting the page preserves saves. Changing hostname or clearing site data starts with separate save data.

## Verification scope

Verified in Chromium: original language selection, sound selection, title, menu, new-game introduction, gameplay/death/continue flow; keyboard input and rendering; responsive layout. Original full-game completion and all cheat codes are not verified.
