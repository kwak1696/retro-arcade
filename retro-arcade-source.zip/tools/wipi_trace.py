"""Bounded native-Clet ABI trace; no JavaVM or browser runtime is supplied.

Table layouts: wipi-types 0.0.4 (MIT), dlunch/wie reference commit recorded
in WIPI-REVERSE.md. Unknown services stop rather than fabricate success.
"""
from wipi_probe import Probe, ROOT, OUT
from zipfile import ZipFile
from unicorn.arm_const import UC_ARM_REG_R1, UC_ARM_REG_SP
import json
import struct
import io
from PIL import Image

SCHEMA=json.loads((ROOT/'tools/wipi-abi.json').read_text())
START={'mini1':0x10fe1d,'mini2':0x10d905,'mini3':0x11796d}
PAINT={'mini1':0x10f8a1,'mini2':0x10e069,'mini3':0x118071}
INPUT={'mini1':0x1108f5,'mini2':0x10e0d9,'mini3':0x1180b9}

class CletTrace(Probe):
    def __init__(self,slug):
        super().__init__()
        (OUT/slug).mkdir(parents=True,exist_ok=True)
        self.slug=slug;self.tables={};self.resources={};self.handles={};self.events=[]
        self.width,self.height=(240,320) if slug=='mini3' else (176,220)
        self.screen=0
        self.timers={};self.pending=[]
        self.frames=0
        self.now=1000
        self.files={};self.fds={}
        with ZipFile(ROOT/'lib'/f'{slug}.jar') as z:
            name=next(n for n in z.namelist() if n.startswith('client.bin'))
            image=z.read(name);self.bss=int(name[10:])
            self.image_size=len(image)+self.bss
            self.resources={n:z.read(n) for n in z.namelist() if not n.startswith(('client.bin','META-INF'))}
        self.uc.mem_map(0x100000,(len(image)+self.bss+4095)&~4095)
        self.uc.mem_write(0x100000,image)
        exe=self.call(0x100001,[self.bss])
        assert not self.halted and exe
        self.exe=self.words(exe,10)
        self.functions=self.words(self.words(self.exe[0])[0],7)

    def table(self,name):
        if name in self.tables:return self.tables[name]
        names=SCHEMA.get(name,[f'unknown_{i}' for i in range(64)])
        addr=self.alloc(len(names)*4);self.tables[name]=addr
        self.write(addr,*[self.stub(f'{name}.{field}',lambda *a,n=name,f=field:self.service(n,f,a)) for field in names])
        return addr

    def unknown(self,label):
        self.halted='unimplemented: '+label;return 0

    def indirect(self,size):
        p=self.alloc(size+12);self.write(p,p+4,size,0);return p

    def framebuffer(self,w,h):
        pixels=self.indirect(w*h*2);fb=self.indirect(20)
        self.write(fb+12,w,h,w*2,16,pixels);return fb

    def fb(self,handle):
        w,h,stride,bpp,pixels=self.words(self.words(handle)[0]+8,5)
        assert bpp==16
        return w,h,stride,self.words(pixels)[0]+8

    def service(self,table,field,args):
        a,b,c,d=args
        stack=self.uc.reg_read(UC_ARM_REG_SP)
        extra=self.words(stack,5)
        if table=='WIPICFsInterface':
            if field=='open':
                name=self.string(a)
                self.events.append({'file_open':name,'flags':b})
                if name not in self.files and b==1:return 0xfffffff4
                if b==4 or name not in self.files:self.files[name]=bytearray()
                fd=self.alloc(4);self.fds[fd]=[name,0,b];return fd
            if field in ('read','write','close','seek'):
                if a not in self.fds:return 0xfffffffe
                fd=self.fds[a];data=self.files[fd[0]]
                if field=='close':del self.fds[a];return 0
                if field=='read':
                    if fd[2] in (2,4):return 0xffffffe8
                    chunk=bytes(data[fd[1]:fd[1]+c])
                    if not chunk and c:return 0xffffffe9
                    if chunk:self.uc.mem_write(b,chunk)
                    fd[1]+=len(chunk);return len(chunk)
                if field=='write':
                    if fd[2]==1:return 0xffffffe8
                    end=fd[1]+c
                    if end>1024*1024:return 0xffffffff
                    if len(data)<end:data.extend(bytes(end-len(data)))
                    data[fd[1]:end]=bytes(self.uc.mem_read(b,c));fd[1]=end;return c
                offset=b if b<0x80000000 else b-0x100000000
                if c not in (0,1,2):return 0xffffffff
                position=[0,fd[1],len(data)][c]+offset
                if position<0:return 0xffffffff
                fd[1]=position;return position
        if table=='WIPICMediaInterface':
            if field in ('get_volume','clip_get_volume'):return 5 # fixed analysis volume
            if field=='clip_create':
                self.events.append({'silent_clip_type':self.string(a),'buffer_size':b,'callback':hex(c)});return self.alloc(16)
            if field=='clip_put_data':return c # analysis-only silent sink
            if field in ('clip_free','stop','pause','play','resume','clip_set_volume','vibrator'):return 0
        if table=='misc_interface' and field=='unknown_0':return 0 # backlight, no visible effect in probe
        if table=='WIPICGraphicsInterface':
            if field in ('draw_image','copy_frame_buffer','copy_area'):
                if field=='copy_area':height,sx,sy,context=extra[:4];source=a
                else:height,source,sx,sy,context=extra
                dw,dh,ds,dp=self.fb(a);sw,sh,ss,sp=self.fb(source)
                signed=lambda n:n if n<0x80000000 else n-0x100000000
                dx,dy,sx,sy=map(signed,[b,c,sx,sy])
                clip=[0,0,dw,dh]
                if context and self.words(context)[0]&1:clip=list(struct.unpack('<4h',bytes(self.uc.mem_read(context+4,8))))
                source_data=bytes(self.uc.mem_read(sp,ss*sh))
                for row in range(max(0,-dy,-sy,clip[1]-dy),min(height,dh-dy,sh-sy,clip[3]-dy)):
                    lo=max(0,-dx,-sx,clip[0]-dx);hi=min(d,dw-dx,sw-sx,clip[2]-dx)
                    if hi>lo:
                        start=(sy+row)*ss+(sx+lo)*2;data=source_data[start:start+(hi-lo)*2]
                        self.uc.mem_write(dp+(dy+row)*ds+(dx+lo)*2,data)
                return 0
            if field=='create_image':
                data=bytes(self.uc.mem_read(self.words(b)[0]+8+c,d))
                image=Image.open(io.BytesIO(data)).convert('RGB');w,h=image.size
                fb=self.framebuffer(w,h);pixels=self.fb(fb)[3]
                rgb=image.tobytes()
                packed=b''.join(struct.pack('<H',((rgb[i]>>3)<<11)|((rgb[i+1]>>2)<<5)|(rgb[i+2]>>3)) for i in range(0,len(rgb),3))
                self.uc.mem_write(pixels,packed)
                handle=self.indirect(72);self.uc.mem_write(handle+12,bytes(self.uc.mem_read(fb+12,20)))
                self.write(a,handle);return 1
            if field=='fill_rect':
                height,context=extra[:2];w,h,stride,pixels=self.fb(a)
                color=self.words(context+12)[0]&65535
                signed=lambda n:n if n<0x80000000 else n-0x100000000
                x,y=signed(b),signed(c)
                for row in range(max(0,y),min(h,y+height)):
                    x0,x1=max(0,x),min(w,x+d)
                    if x1>x0:self.uc.mem_write(pixels+row*stride+x0*2,struct.pack('<H',color)*(x1-x0))
                return 0
            if field=='flush_lcd':
                self.frames+=1;self.events.append({'flush':self.frames,'args':[hex(v) for v in args]})
                w,h,stride,pixels=self.fb(b)
                data=bytes(self.uc.mem_read(pixels,stride*h));rgb=bytearray()
                for row in range(h):
                    for col in range(w):
                        px=struct.unpack_from('<H',data,row*stride+col*2)[0]
                        rgb.extend((((px>>11)&31)*255//31,((px>>5)&63)*255//63,(px&31)*255//31))
                Image.frombytes('RGB',(w,h),bytes(rgb)).save(OUT/self.slug/'last-frame.png')
                return 0
            if field=='get_screen_framebuffer':
                if not self.screen:self.screen=self.framebuffer(self.width,self.height)
                return self.screen
            if field=='create_offscreen_framebuffer':return self.framebuffer(a,b)
            if field=='get_display_info':
                self.write(b,16,16,self.width,self.height,self.width*2,1,0xf800,0x1f,0x7e0);return 1
            if field=='init_context':self.uc.mem_write(a,bytes(56));return 0
            if field=='get_pixel_from_rgb':return ((a>>3)<<11)|((b>>2)<<5)|(c>>3)
            if field=='set_context':
                offsets={1:12,2:16,3:20,4:24,8:48,9:52}
                if b in offsets:self.write(a+offsets[b],c);return 0
                if b==0:
                    mask=self.words(a)[0]
                    if c:self.uc.mem_write(a+4,struct.pack('<4H',*[v&65535 for v in self.words(c,4)]))
                    self.write(a,(mask|1) if c else (mask&~1));return 0
                return self.unknown('graphics context op '+str(b))
        if table=='WIPICKnlInterface':
            if field=='get_access_level':
                self.events.append({'analysis_stub':'get_access_level','value':0});return 0
            if field=='get_system_property':
                name=self.string(a);self.events.append({'property':name})
                value={'RSSILEVEL':'30','BATTERYLEVEL':'100'}.get(name)
                if value is None:return 0xfffffff7
                data=value.encode()+b'\0'
                if len(data)>c:return 0xffffffee
                self.uc.mem_write(b,data);return 0
            if field=='def_timer':
                self.pending=[t for t in self.pending if t['timer']!=hex(a)]
                self.write(a,b);self.timers[a]=b;return 0
            if field=='set_timer':
                if any(t['timer']==hex(a) for t in self.pending):return 0xfffffffb
                self.pending.append({'timer':hex(a),'callback':hex(self.timers.get(a,0)),'delay':b+(c<<32),'param':d});return 0
            if field=='unset_timer':self.pending=[t for t in self.pending if t['timer']!=hex(a)];return 0
            if field=='current_time':
                self.uc.reg_write(UC_ARM_REG_R1,0);return self.now
            if field=='reserved1':
                names=SCHEMA['WIPICInterface']
                types={'graphics_interface':'WIPICGraphicsInterface','fs_interface':'WIPICFsInterface','media_interface':'WIPICMediaInterface'}
                p=self.alloc(len(names)*4)
                self.write(p,*[self.table(types.get(n,n)) for n in names]);return p
            if field in ('alloc','calloc'):
                if not a:return 0
                return self.indirect(a)
            if field=='get_resource_id':
                name=self.string(a).lstrip('/')
                if b:self.write(b,len(self.resources.get(name,b'')))
                self.events.append({'resource':name,'found':name in self.resources})
                if name not in self.resources:return 0xfffffff4
                handle=self.alloc(4);self.handles[handle]=name;return handle
            if field=='get_resource':
                if a not in self.handles:return 0xfffffff7
                data=self.resources[self.handles[a]]
                if len(data)>c:return 0xffffffff
                self.uc.mem_write(self.words(b)[0]+8,data);return 0
            if field=='free':return 0 # bounded bump allocator: memory retained for this trace
            if field=='printk':
                self.events.append({'format':self.string(a),'values':list(args[1:])});return 0
        return self.unknown(table+'.'+field)

    def interface(self,name,*_):
        name=self.string(name)
        return self.table({'WIPIC_knlInterface':'WIPICKnlInterface','WIPI_JBInterface':'WIPIJBInterface'}.get(name,name))

    def tick(self):
        timer=self.pending.pop(0);self.now+=timer['delay']
        self.call(int(timer['callback'],16),[int(timer['timer'],16),timer['param']],max_instructions=15000000)

    def snapshot(self,name):
        frame=OUT/self.slug/'last-frame.png'
        if frame.exists() and self.frames:(OUT/self.slug/(name+'.png')).write_bytes(frame.read_bytes())

    def initialize_abi(self):
        p0=self.alloc(4);p1=self.alloc(4);p2=self.alloc(524);p3=self.alloc(48);p4=self.alloc(48)
        self.write(p3,0,0,0,0,*map(ord,'ZCFDBSIJ'))
        callbacks=[self.stub('get_interface',self.interface),self.stub('java_throw',lambda *_:self.unknown('java_throw')),0,0]
        callbacks += [self.stub('java_service_'+str(i),lambda *_,i=i:self.unknown('java_service_'+str(i))) for i in range(8)]
        self.write(p4,*callbacks)
        value=self.call(self.functions[2],[p0,p1,p2,p3,p4])
        return {'abi_return':hex(value),'abi_stop':self.halted}

    def run(self):
        result=self.initialize_abi()
        if not self.halted:
            result['native_start_return']=hex(self.call(START[self.slug],[0,0],max_instructions=15000000));result['native_start_stop']=self.halted
        if not self.halted:
            self.call(PAINT[self.slug],[0,0,self.width,self.height],max_instructions=15000000)
            result['paint_stop']=self.halted
        ticks=0
        while not self.halted and self.pending and ticks<(40 if self.slug=='mini1' else 650):
            self.tick();ticks+=1
        self.snapshot('boot')
        result['input_probes']=[]
        for attempt in range(2):
            if self.halted:break
            before=self.frames
            self.call(INPUT[self.slug],[2,0xfffffffb,0],max_instructions=15000000)
            if not self.halted:self.call(INPUT[self.slug],[3,0xfffffffb,0],max_instructions=15000000)
            for _ in range(5 if self.slug=='mini1' else 40):
                if self.halted or not self.pending:break
                self.tick()
            self.snapshot('after-ok-'+str(attempt+1))
            result['input_probes'].append({'key':-5,'press_event':2,'release_event':3,'new_flushes':self.frames-before,'stop':self.halted})
        result['timer_ticks']=ticks;result['final_stop']=self.halted;result['flush_count']=self.frames
        result.update(calls=self.calls,events=self.events,instructions=self.instructions,pending_timers=self.pending,
                      analysis_files={name:len(data) for name,data in self.files.items()})
        (OUT/self.slug/'native-trace.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
        return result

if __name__=='__main__':
    for slug in START:
        result=CletTrace(slug).run()
        print(slug,json.dumps({k:v for k,v in result.items() if k not in ('calls','events') }),flush=True)
        print('last calls:',result['calls'][-4:])
