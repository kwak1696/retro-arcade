"""NOM3 LGT machine-code translation; Java object services remain separate."""
from wipi_aot import generate,ROOT
from zipfile import ZipFile
from elftools.elf.elffile import ELFFile
import io,base64,json,struct,gzip,shutil

def build():
    b64=lambda data:base64.b64encode(data).decode()
    with ZipFile(ROOT/'lib/nom3.jar') as z:
        elf=ELFFile(io.BytesIO(z.read('binary.mod')))
        text=elf.get_section_by_name('.text');base=text['sh_addr'];image=text.data()
        segments=[];stubs={}
        for off in range(0,len(image)-15,4):
            first,branch,table,index=struct.unpack_from('<4I',image,off)
            if first==0xe52de004 and branch&0xff000000==0xeb000000:
                stubs[str(base+off)]='lgt|'+str(table)+'|'+str(index)
        for section in elf.iter_sections():
            if section['sh_addr'] and section.name!='.text':
                data=bytes(section['sh_size']) if section['sh_type']=='SHT_NOBITS' else section.data()
                segments.append({'base':section['sh_addr'],'data':b64(data)})
                if section['sh_type']!='SHT_NOBITS':
                    for off in range(0,len(data)-15,4):
                        first,branch,table,index=struct.unpack_from('<4I',data,off)
                        if first==0xe52de004 and branch&0xff000000==0xeb000000:
                            stubs[str(section['sh_addr']+off)]='lgt|'+str(table)+'|'+str(index)
        resources={n:b64(z.read(n)) for n in z.namelist() if n!='binary.mod' and not n.startswith('META-INF') and not n.endswith('.class')}
    out=ROOT/'analysis/wipi/aot';out.mkdir(parents=True,exist_ok=True)
    (ROOT/'analysis/wipi/nom3').mkdir(parents=True,exist_ok=True)
    from wipi_metadata import scan
    classes=scan('nom3')
    generate(image,base,'nom3',out)
    seed={'slug':'nom3','classes':classes,'image_base':base,'image':b64(image),'segments':segments,'heap':'','heap_cursor':0x4000000,'stubs':stubs,'resources':resources,'width':240,'height':320,'entry':elf['e_entry']|1}
    seed['java_abi']=json.loads((ROOT/'tools/lgt-java-abi.json').read_text())
    seed['heap_size']=32*1024*1024
    (out/'nom3-seed.json').write_text(json.dumps(seed,separators=(',',':')))
    for suffix in ('code.mjs','seed.json'):
        (ROOT/'dist'/f'wipi-nom3-{suffix}.gz').write_bytes(gzip.compress((out/f'nom3-{suffix}').read_bytes(),compresslevel=9,mtime=0))
    for name in ('wipi-runtime.mjs','wipi-player.mjs','wipi-lgt-runtime.mjs','wipi-png.mjs','wipi-raster.mjs','fflate.mjs','fflate-LICENSE.txt'):
        shutil.copyfile(ROOT/'src'/name,ROOT/'dist'/name)
    print('NOM3 ARM/Thumb JavaScript generated; runtime API validation required')

if __name__=='__main__':build()
