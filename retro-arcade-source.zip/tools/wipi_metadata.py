"""Recover retained Java AOT class/method records; does not reconstruct bytecode."""
from pathlib import Path
from zipfile import ZipFile
from elftools.elf.elffile import ELFFile
import io, struct, json, re
from capstone import Cs,CS_ARCH_ARM,CS_MODE_THUMB

ROOT=Path(__file__).resolve().parent.parent
BASE=ROOT/'analysis/wipi'
class Memory:
    def __init__(self,ranges):self.ranges=ranges
    def read(self,p,n):
        for base,data in self.ranges:
            if base<=p and p+n<=base+len(data):return data[p-base:p-base+n]
        raise ValueError('outside image')
    def word(self,p):return struct.unpack('<I',self.read(p,4))[0]
    def string(self,p):
        b=bytearray()
        for i in range(500):
            c=self.read(p+i,1)[0]
            if c==0:return b.decode('utf-8')
            b.append(c)
        raise ValueError('unterminated')
    def table(self,p):
        out=[]
        for i in range(2000):
            v=self.word(p+i*4)
            if not v:return out
            out.append(v)
        raise ValueError('unbounded')

def scan(slug):
    if slug=='nom3':
        with ZipFile(ROOT/'lib/nom3.jar') as z:elf=ELFFile(io.BytesIO(z.read('binary.mod')))
        ranges=[(s['sh_addr'],s.data() if s['sh_type']!='SHT_NOBITS' else bytes(s['sh_size'])) for s in elf.iter_sections() if s['sh_addr']]
    else:ranges=[(0x100000,(BASE/slug/'relocated.bin').read_bytes())]
    mem=Memory(ranges);classes={}
    for base,data in ranges:
        for off in range(0,len(data)-12,4):
            p=base+off
            try:
                desc=mem.word(p+8)
                name=mem.string(mem.word(desc+8 if slug=='nom3' else desc))
                if not re.fullmatch(r'[A-Za-z_$][A-Za-z0-9_$/]{0,100}',name):continue
                methods=[]
                if slug=='nom3':
                    table=mem.word(desc+56);count=mem.word(table)
                    if not 0<count<2000:continue
                    for i in range(count):
                        record=table+4+i*28
                        owner,nameptr,sigptr=struct.unpack('<III',mem.read(record,12))
                        if owner!=p:continue
                        method={'name':mem.string(nameptr),'descriptor':mem.string(sigptr),'address':hex(mem.word(record+20)),'record':hex(record)}
                        methods.append(method)
                else:
                    table=mem.word(desc+12)
                    if not table:continue
                    for record in mem.table(table):
                        if mem.word(record+4)!=p:continue
                        full=mem.string(mem.word(record+12)+1)
                        signature,methodname=full.split('+',1)
                        methods.append({'name':methodname,'descriptor':signature,'address':hex(mem.word(record)),'native_or_exceptions':hex(mem.word(record+8)),'record':hex(record)})
                if methods:classes[name]={'class_address':hex(p),'descriptor_address':hex(desc),'methods':methods}
            except (ValueError,UnicodeError,struct.error):pass
    out=BASE/slug
    (out/'aot-metadata.json').write_text(json.dumps(classes,indent=2,ensure_ascii=False),encoding='utf-8')
    lines=[]
    for name,c in classes.items():
        lines.append(f'class {name} @ {c["class_address"]}')
        for method in c['methods']:lines.append(f'  {method["address"]:>10} {method["name"]}{method["descriptor"]}')
    (out/'aot-methods.txt').write_text('\n'.join(lines),encoding='utf-8')
    callmap=[]
    for name,c in classes.items():
        for method in c['methods']:
            addr=int(method['address'],16)
            if slug!='nom3' and method.get('native_or_exceptions')!='0x0' and method['name'] in ['startClet','paintClet','handleInput','pauseClet','destroyClet','resumeClet','layout0']:
                addr=int(method['native_or_exceptions'],16)
            if not addr:continue
            try:
                decoded=list(Cs(CS_ARCH_ARM,CS_MODE_THUMB).disasm(mem.read(addr&~1,256),addr&~1))
                calls=[hex(int(i.op_str[1:],16)) for i in decoded if i.mnemonic in ['bl','blx'] and i.op_str.startswith('#0x')]
                callmap.append({'class':name,'method':method['name'],'address':hex(addr),'direct_calls_in_256_byte_window':calls})
                safe=re.sub(r'[^a-zA-Z0-9_-]','_',name+'-'+method['name'])
                (out/(safe+'.thumb.txt')).write_text('\n'.join(f'{i.address:08x}: {i.mnemonic:8} {i.op_str}' for i in decoded),encoding='utf-8')
            except ValueError:pass
    (out/'method-call-windows.json').write_text(json.dumps(callmap,indent=2),encoding='utf-8')
    print(slug,'classes',len(classes),'methods',sum(len(c['methods']) for c in classes.values()),list(classes)[:25])
    return classes

if __name__=='__main__':
    for slug in ['nom3','mini1','mini2','mini3']:scan(slug)
