"""Render original SMAF resources once; browsers only decode ordinary MP3 audio.

Requires ffmpeg and `pip install ziglang==0.14.1` (or --renderer built separately).
The Apache-2.0 renderer is pinned to upstream commit
627f7ad8583ce34c5fec0269ef9778167af080d6; see vendor/smaf/LICENSE.
"""
from pathlib import Path
from zipfile import ZipFile
from concurrent.futures import ThreadPoolExecutor
import argparse, hashlib, json, subprocess, sys, wave, array, math, shutil

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'analysis/audio'

def run(args):
    return subprocess.run(list(map(str,args)), check=True, capture_output=True, text=True)

def key(data):
    h = 2166136261
    for b in data: h = ((h ^ b) * 16777619) & 0xffffffff
    return f'{h:08x}:{len(data)}'

def main():
    shutil.copyfile(ROOT/'src/game-audio.js',ROOT/'dist/game-audio.js')
    parser=argparse.ArgumentParser(); parser.add_argument('--renderer',type=Path)
    args=parser.parse_args(); OUT.mkdir(parents=True,exist_ok=True)
    renderer=args.renderer or OUT/'smaf-render.exe'
    if not args.renderer:
        vendor=ROOT/'tools/vendor/smaf'
        run([sys.executable,'-m','ziglang','c++','-std=c++20','-O2','-I'+str(vendor/'src'),vendor/'example/smaf-render.cpp',*sorted((vendor/'src').glob('*.cpp')),'-o',renderer])
    vendor=ROOT/'tools/vendor/smaf'
    source_digest=hashlib.sha256(Path(__file__).read_bytes()+b''.join(p.read_bytes() for p in sorted(vendor.rglob('*')) if p.is_file())).hexdigest()[:12]
    for slug in ('nom3','mini1','mini2','mini3'):
        folder=OUT/slug/source_digest;folder.mkdir(parents=True,exist_ok=True)
        with ZipFile(ROOT/'lib'/f'{slug}.jar') as z:
            originals={n:z.read(n) for n in z.namelist() if n.endswith(('.mmf','.wds'))}
        unique={}
        for name,data in originals.items():
            k=key(data)
            if k in unique:
                assert unique[k][1]==data, 'Sound fingerprint collision'
                unique[k][0].append(name)
            else: unique[k]=([name],data)
        def render(item):
            k,(names,data)=item;stem=k.replace(':','-')
            source=folder/(stem+'.mmf');wav=folder/(stem+'.wav');mp3=folder/(stem+'.mp3')
            source.write_bytes(data);fallback=folder/(stem+'.gm');silent=folder/(stem+'.silent')
            if not mp3.exists():
                result=subprocess.run(list(map(str,[renderer,source,wav,300])),capture_output=True,text=True)
                if result.returncode==3:
                    second=subprocess.run(list(map(str,[renderer,source,wav,300,'--gm'])),capture_output=True,text=True)
                    if second.returncode==3:silent.write_text('No audible output from either decoder mode; retained and disclosed for follow-up')
                    elif second.returncode:raise RuntimeError(second.stdout+second.stderr)
                    fallback.write_text('Unsupported custom voice; original score with GM approximation')
                elif result.returncode: raise RuntimeError(result.stdout+result.stderr)
                run(['ffmpeg','-v','error','-y','-i',wav,'-codec:a','libmp3lame','-b:a','80k','-ar','22050',mp3])
            if not wav.exists(): run([renderer,source,wav,300])
            with wave.open(str(wav),'rb') as w:
                seconds=w.getnframes()/w.getframerate();samples=array.array('h',w.readframes(w.getnframes()))
            peak=max(map(abs,samples),default=0)/32768
            rms=math.sqrt(sum(v*v for v in samples)/max(1,len(samples)))/32768
            if (not peak and not silent.exists()) or not 0 < seconds < 300: raise ValueError(f'Invalid render: {slug}/{names}')
            return k,mp3.read_bytes(),dict(names=names,seconds=round(seconds,4),peak=round(peak,5),rms=round(rms,5),gm_fallback=fallback.exists(),silent=silent.exists(),sha256=hashlib.sha256(data).hexdigest())
        with ThreadPoolExecutor(max_workers=4) as pool: rendered=list(pool.map(render,sorted(unique.items())))
        bank=bytearray();index={}
        for k,data,metadata in rendered:
            index[k]=dict(offset=len(bank),length=len(data),**metadata);bank.extend(data)
        (ROOT/'dist'/f'audio-{slug}.bin').write_bytes(bank)
        manifest=dict(version=1,bank=f'audio-{slug}.bin',clips=index)
        (ROOT/'dist'/f'audio-{slug}.json').write_text(json.dumps(manifest,separators=(',',':')),encoding='utf-8')
        print(slug, len(originals),'resources,',len(index),'unique clips,',len(bank),'bytes, silent:',[v['names'] for v in index.values() if v['silent']],flush=True)

if __name__=='__main__':main()
