"""Build-time Thumb-1 -> JavaScript translation. No runtime opcode decoding.

Generated straight-line basic blocks preserve machine integer/memory semantics.
Unsupported instructions are explicit traps, never an interpreter fallback.
"""
import struct,json,base64,gzip,shutil
from pathlib import Path
from wipi_trace import CletTrace, ROOT, START, PAINT, INPUT

def sext(v,b):return v-(1<<b) if v&(1<<(b-1)) else v

def translate_arm(op,pc):
    cond=op>>28
    reg=lambda n:str(pc+8) if n==15 else f'r[{n}]'
    code=''
    if op&0x0ffffff0 in (0x012fff10,0x012fff30):
        code=(f'r[14]={pc+4};' if op&0x20 else '')+f'return m.jump({reg(op&15)});'
    elif op&0x0e000000==0x0a000000:
        code=(f'r[14]={pc+4};' if op&0x01000000 else '')+f'return {pc+8+(sext(op&0xffffff,24)<<2)};'
    elif op&0x0f8000f0==0x00800090:
        signed=bool(op&0x00400000);acc=bool(op&0x00200000);lo=(op>>12)&15;hi=(op>>16)&15
        left=f'BigInt({reg(op&15)}{"|0" if signed else ""})';right=f'BigInt({reg((op>>8)&15)}{"|0" if signed else ""})'
        code=f'q={left}*{right};'
        if acc:code+=f'q+=BigInt(r[{lo}])+(BigInt(r[{hi}])<<32n);'
        code+=f'r[{lo}]=Number(q&0xffffffffn);r[{hi}]=Number((q>>32n)&0xffffffffn);'
        if op&0x00100000:code+=f'm.n=r[{hi}]>>>31;m.z=+(r[{lo}]===0&&r[{hi}]===0);'
    elif op&0x0fc000f0==0x00000090:
        d=(op>>16)&15;a=(op>>12)&15
        expr=f'Math.imul({reg(op&15)},{reg((op>>8)&15)})'
        if op&0x00200000:expr+=f'+{reg(a)}'
        code=f'r[{d}]='+('m.nz('+expr+')' if op&0x100000 else expr)+';'
    elif op&0x0e000000==0x08000000:
        b=(op>>16)&15;regs=[i for i in range(16) if op&(1<<i)];load=bool(op&0x00100000);up=bool(op&0x00800000);pre=bool(op&0x01000000)
        start=(4 if pre else 0) if up else -4*(len(regs)-(0 if pre else 1))
        code=f't=({reg(b)}+{start})>>>0;u={reg(b)};'
        for j,i in enumerate(regs):
            code+=(f'r[{i}]=m.u32(t+{j*4});' if load else f'm.w32(t+{j*4},{reg(i)});')
        if op&0x00200000 and not(load and b in regs):code+=f'r[{b}]=(u{ "+" if up else "-"}{4*len(regs)})>>>0;'
        if load and 15 in regs:code+='return m.jump(r[15]);'
    elif op&0x0c000000==0x04000000:
        b=(op>>16)&15;d=(op>>12)&15;load=bool(op&0x100000);bits=8 if op&0x400000 else 32
        offset=str(op&4095)
        if op&0x02000000:
            kind=(op>>5)&3;amount=(op>>7)&31;value=reg(op&15)
            offset=f'm.rrx({value},false)' if kind==3 and amount==0 else f'm.shift({kind},{value},{32 if not amount and kind else amount},false)'
        code=f't={reg(b)};u=(t{ "+" if op&0x00800000 else "-"}({offset}))>>>0;'
        address='u' if op&0x01000000 else 't'
        code+=(f'r[{d}]=m.u{bits}({address});' if load else f'm.w{bits}({address},{pc+12 if d==15 else reg(d)});')
        if not op&0x01000000 or op&0x00200000:code+=f'r[{b}]=u;'
        if load and d==15:code+='return m.jump(r[15]);'
    elif op&0x0c000000==0:
        kind=(op>>21)&15;s=bool(op&0x00100000);d=(op>>12)&15;a=reg((op>>16)&15)
        logical=kind in (0,1,8,9,12,13,14,15)
        if op&0x02000000:
            amount=((op>>8)&15)*2;value=op&255
            value=((value>>amount)|(value<<(32-amount)))&0xffffffff if amount else value
            b=str(value);prefix=f'm.c={value>>31};' if amount and s and logical else ''
        else:
            shift=(op>>5)&3;amount=(op>>7)&31;byreg=bool(op&16);value=reg(op&15);flags=str(s and logical).lower();prefix=''
            if byreg:amount=f'{reg((op>>8)&15)}&255'
            elif shift in (1,2) and amount==0:amount=32
            if shift==3 and amount==0 and not byreg:b=f'm.rrx({value},{flags})'
            else:b=f'm.shift({shift},{value},{amount},{flags})'
        arithmetic={2:f'm.sub({a},v,{str(s).lower()})',3:f'm.sub(v,{a},{str(s).lower()})',4:f'm.add({a},v,{str(s).lower()})',5:f'm.adc({a},v,{str(s).lower()})',6:f'm.sbc({a},v,{str(s).lower()})',7:f'm.sbc(v,{a},{str(s).lower()})',10:f'm.sub({a},v,true)',11:f'm.add({a},v,true)'}
        logical_expr={0:f'{a}&v',1:f'{a}^v',8:f'{a}&v',9:f'{a}^v',12:f'{a}|v',13:'v',14:f'{a}&~v',15:'~v'}
        expression=arithmetic.get(kind)
        if expression is None:
            expression=logical_expr[kind]
            if s or kind in (8,9):expression=f'm.nz({expression})'
        code=prefix+f'v={b};'
        if kind in (8,9,10,11):code+=expression+';'
        elif d==15:code+=f'return ({expression})&~3;'
        else:code+=f'r[{d}]={expression};'
    if not code:code=f'throw Error("Unsupported ARM translation at {pc:#x}: {op:#x}");'
    return f'if(m.cond({cond})){{{code}}}' if cond<14 else code

def translate(op,pc,following=0):
    r=lambda n:f'r[{n}]'
    reg=lambda n:str(pc+4) if n==15 else r(n)
    done=lambda code:(code,False)
    jump=lambda code:(code,True)
    nxt=pc+2
    if op<0x1800:
        kind=op>>11;shift=(op>>6)&31;s=(op>>3)&7;d=op&7
        return done(f'{r(d)}=m.shift({kind},{r(s)},{shift if kind==0 or shift else 32},true);')
    if op<0x2000:
        imm=(op>>10)&1;sub=(op>>9)&1;b=(op>>6)&7;s=(op>>3)&7;d=op&7
        return done(f'{r(d)}=m.{"sub" if sub else "add"}({r(s)},{b if imm else r(b)},true);')
    if op<0x4000:
        kind=(op>>11)&3;d=(op>>8)&7;imm=op&255
        if kind==0:return done(f'{r(d)}=m.nz({imm});')
        if kind==1:return done(f'm.sub({r(d)},{imm},true);')
        return done(f'{r(d)}=m.{"add" if kind==2 else "sub"}({r(d)},{imm},true);')
    if op&0xfc00==0x4000:
        kind=(op>>6)&15;s=(op>>3)&7;d=op&7;a=r(d);b=r(s)
        expressions={0:f'{a}&{b}',1:f'{a}^{b}',12:f'{a}|{b}',13:f'Math.imul({a},{b})',14:f'{a}&~{b}',15:f'~{b}'}
        if kind in expressions:return done(f'{a}=m.nz({expressions[kind]});')
        if kind in (2,3,4,7):return done(f'{a}=m.shift({{2:0,3:1,4:2,7:3}}[{kind}],{a},{b}&255,true);'.replace('{2:0,3:1,4:2,7:3}', '({2:0,3:1,4:2,7:3})'))
        if kind==5:return done(f'{a}=m.adc({a},{b});')
        if kind==6:return done(f'{a}=m.sbc({a},{b});')
        if kind==8:return done(f'm.nz({a}&{b});')
        if kind==9:return done(f'{a}=m.sub(0,{b},true);')
        return done(f'm.{"sub" if kind==10 else "add"}({a},{b},true);')
    if op&0xfc00==0x4400:
        kind=(op>>8)&3;s=(op>>3)&15;d=(op&7)|((op>>4)&8)
        if kind==3:return jump(f'{"r[14]="+str(nxt|1)+";" if op&128 else ""}return m.jump({reg(s)});')
        if kind==1:return done(f'm.sub({reg(d)},{reg(s)},true);')
        value=f'({reg(d)}+{reg(s)})>>>0' if kind==0 else reg(s)
        if d==15:return jump(f'return ({value})&~1;')
        return done(f'{r(d)}={value};')
    if op&0xf800==0x4800:
        return done(f'{r((op>>8)&7)}=m.u32({((pc+4)&~3)+(op&255)*4});')
    if op&0xf000==0x5000:
        kind=(op>>9)&7;offset=r((op>>6)&7);base=r((op>>3)&7);d=r(op&7);addr=f'({base}+{offset})>>>0'
        if kind<3:
            return done(f'm.w{[32,16,8][kind]}({addr},{d});')
        load={3:'i8',4:'u32',5:'u16',6:'u8',7:'i16'}[kind]
        return done(f'{d}=m.{load}({addr});')
    if op&0xe000==0x6000:
        byte=bool(op&0x1000);load=bool(op&0x800);off=((op>>6)&31)*(1 if byte else 4);b=r((op>>3)&7);d=r(op&7);addr=f'({b}+{off})>>>0';bits=8 if byte else 32
        return done(f'{d}=m.u{bits}({addr});' if load else f'm.w{bits}({addr},{d});')
    if op&0xf000==0x8000:
        addr=f'({r((op>>3)&7)}+{((op>>6)&31)*2})>>>0';d=r(op&7)
        return done(f'{d}=m.u16({addr});' if op&0x800 else f'm.w16({addr},{d});')
    if op&0xf000==0x9000:
        addr=f'(r[13]+{(op&255)*4})>>>0';d=r((op>>8)&7)
        return done(f'{d}=m.u32({addr});' if op&0x800 else f'm.w32({addr},{d});')
    if op&0xf000==0xa000:
        base='r[13]' if op&0x800 else str((pc+4)&~3)
        return done(f'{r((op>>8)&7)}=({base}+{(op&255)*4})>>>0;')
    if op&0xff00==0xb000:
        return done(f'r[13]=(r[13]{"-" if op&128 else "+"}{(op&127)*4})>>>0;')
    if op&0xf600==0xb400:
        regs=[i for i in range(8) if op&(1<<i)]
        pop=bool(op&0x800)
        if op&0x100:regs.append(15 if pop else 14)
        if pop:
            code=''.join(f'{r(i)}=m.u32(r[13]);r[13]+=4;' for i in regs)
            return jump(code+'return m.jump(r[15]);') if 15 in regs else done(code)
        return done(f'r[13]-={len(regs)*4};'+''.join(f'm.w32(r[13]+{j*4},{r(i)});' for j,i in enumerate(regs)))
    if op&0xf000==0xc000:
        b=(op>>8)&7;regs=[i for i in range(8) if op&(1<<i)];load=bool(op&0x800)
        code=f't={r(b)};'
        code+=''.join((f'{r(i)}=m.u32(t+{j*4});' if load else f'm.w32(t+{j*4},{r(i)});') for j,i in enumerate(regs))
        if not(load and b in regs):code+=f'{r(b)}=t+{len(regs)*4};'
        return done(code)
    if op&0xf000==0xd000:
        cond=(op>>8)&15
        if cond<14:return jump(f'return m.cond({cond})?{pc+4+sext(op&255,8)*2}:{nxt};')
    if op&0xf800==0xe000:return jump(f'return {pc+4+sext(op&2047,11)*2};')
    if op&0xf800==0xf000 and following&0xf800 in (0xf800,0xe800):
        target=pc+4+(sext(op&2047,11)<<12)+((following&2047)<<1)
        if following&0xf800==0xe800:return jump(f'r[14]={pc+5};return m.jump({target&~3});')
        return jump(f'r[14]={pc+5};return {target};')
    return jump(f'throw Error("Unsupported translated instruction at {pc:#x}: {op:#06x}");')

def generate(image,base,slug,out):
    lines=['export default function install(m){const r=m.r,p=m.program,a=m.armProgram;let t,u,v,q;']
    for offset in range(0,len(image)-1,64):
        pcs=[];body=[]
        for pos in range(offset,min(offset+64,len(image)-1),2):
            pc=base+pos;pcs.append(pc)
            op=struct.unpack_from('<H',image,pos)[0];following=struct.unpack_from('<H',image,pos+2)[0] if pos+4<=len(image) else 0
            code,end=translate(op,pc,following)
            body.append(f'case {pc}:{code}')
            if end:body[-1]+=''
        name='b'+str(offset//64)
        lines.append(f'function {name}(pc){{switch(pc){{'+''.join(body)+f'}}return {base+offset+64};}}')
        lines.append(''.join(f'p[{(pc-base)//2}]={name};' for pc in pcs))
    lines.append('}')
    lines.pop()
    for offset in range(0,len(image)-3,64):
        pcs=[];body=[]
        for pos in range(offset,min(offset+64,len(image)-3),4):
            pc=base+pos;pcs.append(pc)
            body.append(f'case {pc}:'+translate_arm(struct.unpack_from('<I',image,pos)[0],pc))
        name='a'+str(offset//64)
        lines.append(f'function {name}(pc){{switch(pc){{'+''.join(body)+f'}}return {base+offset+64};}}')
        lines.append(''.join(f'a[{(pc-base)//4}]={name};' for pc in pcs))
    lines.append('}')
    (out/f'{slug}-code.mjs').write_text('\n'.join(lines))

def build(slug):
    p=CletTrace(slug);result=p.initialize_abi();assert result['abi_stop'] is None
    image_size=p.image_size
    image=bytes(p.uc.mem_read(0x100000,image_size))
    out=ROOT/'analysis/wipi/aot';out.mkdir(parents=True,exist_ok=True)
    generate(image,0x100000,slug,out)
    seed={'slug':slug,'image':base64.b64encode(image).decode(),'heap':base64.b64encode(bytes(p.uc.mem_read(0x4000000,p.heap-0x4000000))).decode(),
          'heap_cursor':p.heap,'start':START[slug],'paint':PAINT[slug],'input':INPUT[slug],
          'width':p.width,'height':p.height,'stubs':{str(addr):key for addr,(key,_) in p.stubs.items()},
          'resources':{name:base64.b64encode(data).decode() for name,data in p.resources.items()}}
    (out/f'{slug}-seed.json').write_text(json.dumps(seed,separators=(',',':')))
    for suffix in ('code.mjs','seed.json'):
        (ROOT/'dist'/f'wipi-{slug}-{suffix}.gz').write_bytes(gzip.compress((out/f'{slug}-{suffix}').read_bytes(),compresslevel=9,mtime=0))
    print(slug,'translated',len(image)//2,'Thumb entry addresses')

if __name__=='__main__':
    for slug in START:build(slug)
    for name in ('wipi-runtime.mjs','wipi-player.mjs'):shutil.copyfile(ROOT/'src'/name,ROOT/'dist'/name)
