"""Inventory original resource containers without publishing their contents.

WDI header hypothesis checked against all 668 mini1 files. Payload codec and
the meaning of palette references remain unconfirmed. WDS headers identify
SMAF/MMMD; this tool does not claim to decode its music events.
"""
from wipi_probe import ROOT, OUT
from zipfile import ZipFile
import struct, json, hashlib

def inspect(name,data):
    result={'name':name,'size':len(data),'sha256':hashlib.sha256(data).hexdigest()}
    if name.endswith('.wdi'):
        if len(data)<12:raise ValueError('short WDI header')
        width,height,x,y,count=struct.unpack_from('<HHhhH',data)
        offset=10+count*2
        if offset+2>len(data):raise ValueError('WDI palette exceeds input')
        length=struct.unpack_from('<H',data,offset)[0]
        if offset+2+length!=len(data):raise ValueError('WDI payload length mismatch')
        result.update(format='custom WDI',width=width,height=height,anchor_candidate=[x,y],
                      palette_words=list(struct.unpack_from('<'+'H'*count,data,10)),
                      payload_offset=offset+2,payload_size=length)
    elif data.startswith(b'MMMD'):
        end=8+struct.unpack_from('>I',data,4)[0]
        chunks=[];pos=8
        while pos+8<=min(len(data),end):
            size=struct.unpack_from('>I',data,pos+4)[0]
            if pos+8+size>min(len(data),end):break
            chunks.append({'id':data[pos:pos+4].hex(),'offset':pos,'size':size})
            pos+=8+size
        result.update(format='SMAF MMMD',declared_end=end,trailing_bytes=len(data)-end,
                      top_level_chunks=chunks,unparsed_declared_bytes=max(0,end-pos))
    elif data.startswith(b'\x89PNG\r\n\x1a\n'):result['format']='PNG'
    elif data.startswith(b'BM'):result['format']='BMP'
    elif name.endswith('.bar'):result['format']='custom BAR; codec not yet recovered'
    else:result['format']='unclassified'
    return result

def main():
    summary={}
    for slug in ('nom3','mini1','mini2','mini3'):
        with ZipFile(ROOT/'lib'/f'{slug}.jar') as z:
            records=[inspect(n,z.read(n)) for n in z.namelist()
                     if n.endswith(('.wdi','.wds','.bar','.bmp','.png'))]
        dest=OUT/slug;dest.mkdir(parents=True,exist_ok=True)
        (dest/'resource-inventory.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
        summary[slug]={'resources':len(records),'formats':{kind:sum(r['format']==kind for r in records) for kind in sorted({r['format'] for r in records})}}
    assert summary['mini1']['formats']['custom WDI']==668
    (OUT/'resource-summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
