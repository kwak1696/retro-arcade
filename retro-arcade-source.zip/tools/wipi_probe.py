"""Bounded reverse-engineering probes. Requires pyelftools, capstone, unicorn.

Executes only initialization/relocation in isolated emulated memory. No host
network, filesystem, handset services, or game rendering is exposed to guests.
ABI layout cross-checked against dlunch/wie and wipi-types 0.0.4 (MIT).
"""
from pathlib import Path
from zipfile import ZipFile
import io, json, struct, hashlib, re
from capstone import Cs, CS_ARCH_ARM, CS_MODE_THUMB
from elftools.elf.elffile import ELFFile
from unicorn import Uc, UC_ARCH_ARM, UC_MODE_THUMB, UC_HOOK_CODE, UcError
from unicorn.arm_const import UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R2, UC_ARM_REG_R3, UC_ARM_REG_SP, UC_ARM_REG_LR, UC_ARM_REG_PC

ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'analysis/wipi'
REGS=[UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2,UC_ARM_REG_R3]

class Probe:
    def __init__(self):
        self.uc=Uc(UC_ARCH_ARM,UC_MODE_THUMB)
        self.uc.mem_map(0x3000000,0x100000)
        self.uc.mem_map(0x4000000,0x200000)
        self.uc.mem_map(0x7000000,0x100000)
        self.heap=0x4000000;self.stub_cursor=0x3000010
        self.stubs={};self.calls=[];self.halted=None;self.instructions=0
        self.uc.hook_add(UC_HOOK_CODE,self.hook)
    def alloc(self,size):
        p=self.heap;self.heap+=(size+7)&~7
        if self.heap>0x4200000: raise RuntimeError('bounded probe heap exhausted')
        return p
    def words(self,p,n=1):return struct.unpack('<'+'I'*n,bytes(self.uc.mem_read(p,n*4)))
    def write(self,p,*words):self.uc.mem_write(p,struct.pack('<'+'I'*len(words),*words))
    def string(self,p):
        if not p:return ''
        data=bytearray()
        for i in range(512):
            b=self.uc.mem_read(p+i,1)[0]
            if not b:break
            data.append(b)
        return data.decode('utf-8','replace')
    def stub(self,key,callback):
        for p,(k,_) in self.stubs.items():
            if k==key:return p|1
        p=self.stub_cursor;self.stub_cursor+=4
        self.uc.mem_write(p,b'\x70\x47\x00\xbf')
        self.stubs[p]=(key,callback);return p|1
    def hook(self,uc,address,size,data):
        self.instructions+=1
        if address==0x3000000:uc.emu_stop();return
        if address in self.stubs:
            key,callback=self.stubs[address]
            args=[uc.reg_read(r) for r in REGS]
            self.calls.append({'function':key,'caller':hex(uc.reg_read(UC_ARM_REG_LR)),'args':[hex(a) for a in args]})
            result=callback(*args)
            if self.halted:uc.emu_stop();return
            uc.reg_write(UC_ARM_REG_R0,result or 0)
            uc.reg_write(UC_ARM_REG_PC,uc.reg_read(UC_ARM_REG_LR))
    def call(self,pc,args=(),max_instructions=3000000):
        self.halted=None
        for i,r in enumerate(REGS):self.uc.reg_write(r,args[i] if i<len(args) else 0)
        self.uc.reg_write(UC_ARM_REG_SP,0x70ff000)
        for i,a in enumerate(args[4:]):self.write(0x70ff000+i*4,a)
        self.uc.reg_write(UC_ARM_REG_LR,0x3000001)
        try:self.uc.emu_start(pc,0,count=max_instructions)
        except UcError as e:self.halted=f'{e}; pc={self.uc.reg_read(UC_ARM_REG_PC):#x}'
        if self.uc.reg_read(UC_ARM_REG_PC)!=0x3000000 and not self.halted:self.halted='instruction budget reached'
        return self.uc.reg_read(UC_ARM_REG_R0)

def disassemble(probe,addr,dest,length=256):
    data=bytes(probe.uc.mem_read(addr&~1,length))
    text='\n'.join(f'{i.address:08x}: {i.bytes.hex():10} {i.mnemonic:8} {i.op_str}' for i in Cs(CS_ARCH_ARM,CS_MODE_THUMB).disasm(data,addr&~1))
    dest.write_text(text,encoding='utf-8')

def ktf(slug):
    out=OUT/slug;out.mkdir(exist_ok=True,parents=True)
    with ZipFile(ROOT/'lib'/f'{slug}.jar') as z:
        filename=next(n for n in z.namelist() if n.startswith('client.bin'));image=z.read(filename)
    bss=int(filename.removeprefix('client.bin'));p=Probe();base=0x100000
    p.uc.mem_map(base,(len(image)+bss+0xfff)&~0xfff);p.uc.mem_write(base,image)
    exe=p.call(base|1,[bss])
    result={'format':'KTF client.bin ARM/Thumb','sha256':hashlib.sha256(image).hexdigest(),'image_base':hex(base),'image_size':len(image),'bss_size':bss,'relocation_return':hex(exe),'relocation_stop':p.halted,'instructions':p.instructions}
    if not p.halted and exe:
        values=p.words(exe,10);interface=p.words(values[0],8);functions=p.words(interface[0],7)
        result.update(exe_words=[hex(v) for v in values],interface_name=p.string(interface[1]),exe_name=p.string(values[1]),interface_functions=[hex(v) for v in functions])
        if result['interface_name']!='ExeInterface' or result['exe_name']!='WIPI_exe':raise RuntimeError('relocated image did not expose expected interface records')
        negative=Probe();negative.uc.mem_map(base,(len(image)+bss+0xfff)&~0xfff);negative.uc.mem_write(base,image)
        result['wrong_bss_return']=hex(negative.call(base|1,[bss+4]))
        if result['wrong_bss_return']!='0x0':raise RuntimeError('BSS mismatch negative control did not reject the image')
        relocated=bytes(p.uc.mem_read(base,len(image)+bss));(out/'relocated.bin').write_bytes(relocated)
        for name,addr in [('exe-interface-init',functions[2]),('wipi-init',values[5]),('get-default-dll',functions[3]),('get-class',functions[4])]:
            if addr and base<=(addr&~1)<base+len(image):disassemble(p,addr,out/(name+'.thumb.txt'))
        # A dry ABI initialization records requested interfaces and stops there.
        def interface_request(name,*_):
            result.setdefault('interface_requests',[]).append(p.string(name));p.halted='stopped at first handset interface request (not implemented)';return 0
        def unavailable(*_):p.halted='stopped at an unimplemented handset service';return 0
        param0=p.alloc(4);param3=p.alloc(48);param4=p.alloc(48)
        p.write(param3,0,0,0,0,*map(ord,'ZCFDBSIJ'))
        callbacks=[p.stub('get_interface',interface_request),p.stub('java_throw',unavailable),0,0]+[p.stub('java_service_'+str(i),unavailable) for i in range(8)]
        p.write(param4,*callbacks)
        p.call(functions[2],[param0,0,0,param3,param4]);result['abi_init_stop']=p.halted;result['calls']=p.calls
        strings=[m.group().decode('ascii') for m in re.finditer(rb'[\x20-\x7e]{6,}',relocated)]
        (out/'strings-ascii.txt').write_text('\n'.join(strings),encoding='utf-8')
    (out/'probe.json').write_text(json.dumps(result,indent=2),encoding='utf-8');return result

def lgt(extended=False):
    out=OUT/('nom3-extended' if extended else 'nom3');out.mkdir(exist_ok=True,parents=True)
    with ZipFile(ROOT/'lib/nom3.jar') as z:image=z.read('binary.mod')
    elf=ELFFile(io.BytesIO(image));p=Probe();sections=[]
    for s in elf.iter_sections():
        sections.append({'name':s.name,'address':hex(s['sh_addr']),'size':s['sh_size'],'type':s['sh_type']})
        if s['sh_addr'] and s['sh_size']:
            addr=s['sh_addr'];start=addr&~0xfff;size=(addr-start+s['sh_size']+0xfff)&~0xfff
            p.uc.mem_map(start,size)
            if s['sh_type']!='SHT_NOBITS':p.uc.mem_write(addr,s.data())
    result={'format':'LGT Raptor ELF32 ARM Thumb','sha256':hashlib.sha256(image).hexdigest(),'entry':hex(elf['e_entry']|1),'sections':sections}
    registered={}
    def import_table(table,*_):return table
    def service(table,index):
        def invoke(*args):
            if extended and table==0x64 and index==3:return 0 # WIE java_unk0 is a no-op; not a Java runtime implementation.
            if extended and table in (0x1fc,0x1ff,0x201) and index==3:return 0 # WIE java_unk1/2/3
            if extended and table==1 and index==0x418:
                p.uc.mem_write(args[0],bytes([args[1]&255])*args[2]);return args[0]
            if extended and table==0x64 and index==7:
                result['runtime_context_probe']='metadata discovery only; Java class loader not instantiated'
                return args[0]
            if extended and table==0x64 and index==0x14:
                params=list(args)+list(p.words(p.uc.reg_read(UC_ARM_REG_SP),7))
                records=[]
                for i in range(p.words(params[0])[0]):
                    raw=struct.unpack('<I10H',bytes(p.uc.mem_read(params[0]+4+i*24,24)))
                    record={'class':p.string(raw[0]),'members':{}}
                    for j,kind in enumerate(['instance_fields','static_fields','virtual_methods','interface_methods','direct_methods']):
                        offset,count=raw[1+j*2:3+j*2];members=[]
                        for k in range(offset,offset+count):
                            name,desc=p.words(params[1+j]+k*8,2)
                            members.append({'name':p.string(name),'descriptor':p.string(desc)})
                        record['members'][kind]=members
                    records.append(record)
                result['imported_classes']=records
                named=[(r['class'],kind,m) for r in records for kind,entries in r['members'].items() for m in entries if m['name']]
                result['imported_class_count']=len(records);result['imported_named_member_count']=len(named)
                (out/'imported-api.txt').write_text('\n'.join(f"{cls}.{m['name']}{m['descriptor']} [{kind}]" for cls,kind,m in named),encoding='utf-8')
                p.halted='stopped before Java imported class linking (metadata captured)';return 0
            if table==0x1fb and index==3:
                registered.update(zip(['start','pause','resume','destroy','paint','event'],p.words(args[0],6)));return 0
            p.halted=f'stopped at runtime API {table:#x}:{index:#x}';return 0
        return invoke
    def import_function(table,index,*_):return p.stub(f'import:{table:#x}:{index:#x}',service(table,index))
    param1=p.alloc(536);param2=p.alloc(16)
    p.write(param2,p.stub('get_import_table',import_table),p.stub('get_import_function',import_function),0,0)
    p.call(elf['e_entry']|1,[param1,param2,0]);initstruct=p.words(param1+532)[0]
    result['entry_stop']=p.halted;result['init_struct']=hex(initstruct)
    if initstruct:
        init=p.words(initstruct,3);result['init_words']=[hex(v) for v in init];result['init_name']=p.string(init[2])
        disassemble(p,elf['e_entry']|1,out/'entry.thumb.txt',24)
        disassemble(p,init[1],out/'initializer.thumb.txt',512)
        p.call(init[1]);result['initializer_stop']=p.halted
        result['callbacks']={k:hex(v) for k,v in registered.items()}
        for k,v in registered.items():
            if v:disassemble(p,v,out/(k+'.thumb.txt'))
        if registered.get('start'):
            p.call(registered['start'],[0,0,0]);result['start_stop']=p.halted
    result['calls']=p.calls;result['instructions']=p.instructions
    imports={c['function'] for c in p.calls if c['function'].startswith('import:')}
    result['runtime_calls']=sorted(imports)
    result['linked_imports']=sorted({k for k,_ in p.stubs.values() if k.startswith('import:')})
    (out/'probe.json').write_text(json.dumps(result,indent=2),encoding='utf-8');return result

if __name__=='__main__':
    OUT.mkdir(exist_ok=True,parents=True)
    results={}
    for slug in ['nom3','mini1','mini2','mini3']:
        try:results[slug]=lgt() if slug=='nom3' else ktf(slug)
        except Exception as e:results[slug]={'error':repr(e)}
        print(slug,json.dumps({k:v for k,v in results[slug].items() if k not in ['calls','sections','linked_imports']},ensure_ascii=False))
    (OUT/'summary.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
