import fs from 'node:fs';
import assert from 'node:assert/strict';
import {WipiRuntime} from '../src/wipi-runtime.mjs';
const root=new URL('../analysis/wipi/aot/',import.meta.url);
for(const slug of ['mini1','mini2','mini3']){
 const seed=JSON.parse(fs.readFileSync(new URL(slug+'-seed.json',root)));
 const {default:install}=await import(new URL(slug+'-code.mjs',root));
 let latest;
 const m=new WipiRuntime(seed,{present:(fb,data)=>latest={fb,data}});install(m);
 const started=Date.now();let stopped=null;
 const tick=()=>{const due=Math.min(...[...m.pending.values()].map(t=>t.due));m.tick(due);};
 const snapshot=name=>{if(latest)fs.writeFileSync(new URL(slug+'-'+name+'.rgb565',root),latest.data);};
 try{
  m.call(seed.start,[0,0]);m.call(seed.paint,[0,0,seed.width,seed.height]);
  for(let i=0;i<(slug==='mini1'?40:650)&&m.pending.size;i++)tick();
  snapshot('boot');
  for(let i=0;i<2;i++){
   m.call(seed.input,[2,0xfffffffb,0]);m.call(seed.input,[3,0xfffffffb,0]);
   for(let j=0;j<(slug==='mini1'?5:40)&&m.pending.size;j++)tick();snapshot('after-ok-'+(i+1));
  }
 }catch(e){stopped=e.message;console.log(slug,'stop',stopped,m.calls.slice(-5));}
 assert(m.frames>0,'translated program must present a real framebuffer');
 if(slug!=='mini3')assert.equal(stopped,null);
 console.log(slug,JSON.stringify({ms:Date.now()-started,frames:m.frames,stop:stopped,heap:m.cursor-0x4000000}));
 fs.writeFileSync(new URL(slug+'-validation.json',root),JSON.stringify({frames:m.frames,stop:stopped,files:Object.fromEntries([...m.files].map(([k,v])=>[k,v.length]))},null,2));
}
