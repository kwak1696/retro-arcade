import fs from 'node:fs';
import assert from 'node:assert/strict';
import {WipiRuntime} from '../src/wipi-runtime.mjs';
import {LgtRuntime} from '../src/wipi-lgt-runtime.mjs';
import '../src/game-audio.js';
const key=bytes=>{let h=2166136261;for(const b of bytes)h=Math.imul(h^b,16777619);return (h>>>0).toString(16).padStart(8,'0')+':'+bytes.length;};
for(const slug of ['mini1','mini2','mini3','nom3']){
 const manifest=JSON.parse(fs.readFileSync(new URL('../dist/audio-'+slug+'.json',import.meta.url)));
 const bank=fs.readFileSync(new URL('../dist/'+manifest.bank,import.meta.url));
 const seed=JSON.parse(fs.readFileSync(new URL('../analysis/wipi/aot/'+slug+'-seed.json',import.meta.url)));
 let resources=0;const events=[];
 for(const [name,data] of Object.entries(seed.resources))if(/\.(mmf|wds)$/.test(name)){
  const entry=manifest.clips[key(Buffer.from(data,'base64'))];assert(entry,name);assert(entry.offset+entry.length<=bank.length);assert(entry.seconds>0);assert(entry.peak>0||entry.silent);resources++;
 }
 const audio={create(bytes){const entry=manifest.clips[key(bytes)];assert(entry,'Game passed an unknown sound');events.push(['load',entry.names[0]]);return {entry};},play(c,loop){if(c)events.push(['play',c.entry.names[0],loop]);},stop(c){if(c)events.push(['stop',c.entry.names[0]]);},setVolume(){},setMasterVolume(value){events.push(['volume',value]);},pause(){},resume(){}};
 const m=slug==='nom3'?new LgtRuntime(seed,{audio}):new WipiRuntime(seed,{audio});
 const {default:install}=await import(new URL('../analysis/wipi/aot/'+slug+'-code.mjs',import.meta.url));install(m);
 if(slug==='nom3'){
  m.initialize();m.start();m.repaintRequested=true;let time=1000;
  const ticks=n=>{for(let i=0;i<n;i++)m.advance(time+=50);};ticks(400);
  for(let i=0;i<14;i++){for(const down of [1,2])m.call(m.u32(m.u32(m.card)+26*4),[m.card,down,0xfffffffb]);ticks(40);}
  ticks(150);
 }else{
  m.call(seed.start,[0,0]);m.call(seed.paint,[0,0,seed.width,seed.height]);
  const ticks=n=>{for(let i=0;i<n&&m.pending.size;i++)m.tick(Math.min(...[...m.pending.values()].map(t=>t.due)));};ticks(650);
  for(let i=0;i<4;i++){for(const down of [2,3])m.call(seed.input,[down,0xfffffffb,0]);ticks(40);}
 }
 assert(events.some(e=>e[0]==='play'),slug+' should trigger audio from real game code');
 console.log(slug,resources,'assets;',JSON.stringify(events.filter(e=>e[0]!=='load').slice(0,16)));
}
// Late decode completion must not restart a stopped clip or an earlier play.
let finishDecode;const sources=[];
const context={currentTime:5,state:'running',decodeAudioData:()=>new Promise(resolve=>finishDecode=resolve),createBufferSource(){const s={connect(){},disconnect(){},start(){s.started=true;},stop(){s.stopped=true;}};sources.push(s);return s;},createGain:()=>({gain:{value:1},connect(){},disconnect(){}})};
const engine=new globalThis.GameAudio();engine.context=context;engine.master={gain:{value:1}};
const clip=engine.create(Uint8Array.of(1,2,3));const first=engine.play(clip,true);engine.stop(clip);finishDecode({duration:10});await first;assert.equal(sources.length,0);
await engine.play(clip,true);assert(sources[0].started);engine.setMute(true);assert.equal(engine.master.gain.value,0);assert(!sources[0].stopped);engine.pause(clip);assert(sources[0].stopped);await engine.resume(clip);assert(sources[1].started);engine.stopAll();assert.equal(engine.active.size,0);
console.log('Audio cancellation, mute, pause/resume and stop checks passed');
