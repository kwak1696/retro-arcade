import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const source=fs.readFileSync('dist/app.js','utf8');
const fn=source.slice(source.indexOf('function input('),source.indexOf('\n',source.indexOf('window.nomHost.key?.(mapped,down);')));
const events=[];const context=vm.createContext({started:true,selectedGame:'nom2',gameConfig:{},window:{nomHost:{key:(...args)=>events.push(args)}},toast(){}});
vm.runInContext(fn,context);
const mapping=[114,116,121,102,103,104,118,98,110];
for(let n=1;n<=9;n++){context.input(48+n,true,true,true);assert.deepEqual(events.pop(),[mapping[n-1],true]);context.input(48+n,false,true,true);assert.deepEqual(events.pop(),[mapping[n-1],false]);}
for(const [key,result] of [[50,-1],[56,-2],[52,-3],[54,-4],[53,-5]]){context.input(key,true);assert.deepEqual(events.pop(),[result,true]);}
for(const slug of ['nom','nom3','mini1','mini2','mini3']){context.selectedGame=slug;context.input(49,true,true,true);assert.deepEqual(events.pop(),[49,true]);}
context.selectedGame='nom2';
const handlers={};context.window.addEventListener=(name,fn)=>handlers[name]=fn;context.document={querySelectorAll:()=>[]};
const begin=source.indexOf('const keymap=');const end=source.indexOf('// Fullscreen controls',begin);
vm.runInContext(source.slice(begin,end),context);
const event=(key,code)=>({key,code,preventDefault(){}});
handlers.keydown(event('1','Digit1'));handlers.keydown(event('3','Digit3'));handlers.keyup(event('1','Digit1'));handlers.keyup(event('3','Digit3'));
assert.deepEqual(events.splice(0),[[114,true],[121,true],[114,false],[121,false]]);
handlers.keydown(event('5','Digit5'));handlers.keydown(event('Enter','Enter'));handlers.blur();
assert.deepEqual(events.splice(0),[[103,true],[-5,true],[103,false],[-5,false]]);
console.log('PASS: all NOM2 numeric mappings, physical 1/3, independent 5/OK, blur release, other-game numeric isolation.');
