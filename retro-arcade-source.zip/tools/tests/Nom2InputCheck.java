import java.lang.reflect.*;
import sun.misc.Unsafe;
public class Nom2InputCheck {
 static void set(String name,Object value)throws Exception{Field f=e.class.getDeclaredField(name);f.setAccessible(true);f.set(null,value);}
 public static void main(String[] args)throws Exception{
  Field uf=Unsafe.class.getDeclaredField("theUnsafe");uf.setAccessible(true);Unsafe u=(Unsafe)uf.get(null);
  e game=(e)u.allocateInstance(e.class);
  for(Field f:e.class.getDeclaredFields()){
   f.setAccessible(true);Class<?> t=f.getType();
   if(t.isArray()&&t.getComponentType().isPrimitive()&&(!Modifier.isStatic(f.getModifiers())||f.get(null)==null))f.set(Modifier.isStatic(f.getModifiers())?null:game,Array.newInstance(t.getComponentType(),1024));
  }
  game.dl_12aba=(m)u.allocateInstance(m.class);
  set("cR_5a",false);set("bM_5a",false);set("bi_49",0);set("Y_49",0);set("bL_49",2);set("ay_5a",true);
  game.input(49,true);game.input(51,true);
  if(game.ep_b47[0]!=0||game.ep_b47[1]!=0)throw new AssertionError("raw digits unexpectedly work");
  game.input(Integer.parseInt(args[0]),true);
  if(game.ep_b47[0]!=1||game.ep_b47[1]!=0||game.eq_b47[0]!=4)throw new AssertionError("1 must jump runner 0 only");
  game.input(Integer.parseInt(args[1]),true);
  if(game.ep_b47[1]!=1||game.eq_b47[1]!=4)throw new AssertionError("3 must jump runner 1");
  game.input(Integer.parseInt(args[0]),false);game.input(Integer.parseInt(args[1]),false);
  System.out.println("PASS: raw 49/51 ignored; mapped 1/3 independently set original runner jump ep=1, eq=4.");
 }
}

