"""Embed only original data assets; no bytecode is served at runtime."""
import base64
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile

root = Path(__file__).resolve().parent.parent
for jar, output in [('NOM.jar', 'resources.json'), ('NOM2.jar', 'resources-nom2.json')]:
    source = root / 'lib' / jar
    with ZipFile(source) as archive:
        data = {name: base64.b64encode(archive.read(name)).decode('ascii')
                for name in archive.namelist()
                if not name.endswith(('.class', '/'))}
        manifest = archive.read('META-INF/MANIFEST.MF').decode('utf-8').replace('\r', '')
        data['__properties'] = dict(line.split(': ', 1) for line in manifest.splitlines() if ': ' in line)
    (root / 'dist' / output).write_text(json.dumps(data), encoding='utf-8')
    print(jar, 'SHA-256:', hashlib.sha256(source.read_bytes()).hexdigest())
