"""ABI boundary checks; these do not establish full game correctness."""
import unittest
import struct
from unicorn.arm_const import UC_ARM_REG_SP
from wipi_trace import CletTrace
from wipi_resources import inspect

class TraceTests(unittest.TestCase):
    def setUp(self):self.p=CletTrace('mini1')
    def invoke(self,table,field,*args):return self.p.service(table,field,tuple(args)+(0,)*(4-len(args)))
    def string(self,value):
        data=value.encode()+b'\0';addr=self.p.alloc(len(data));self.p.uc.mem_write(addr,data);return addr
    def test_indirect_memory_and_resource_copy(self):
        name=self.string('24.wdi');size=self.p.alloc(4)
        handle=self.invoke('WIPICKnlInterface','get_resource_id',name,size)
        expected=self.p.resources['24.wdi'];self.assertEqual(self.p.words(size)[0],len(expected))
        buffer=self.invoke('WIPICKnlInterface','calloc',len(expected))
        self.assertEqual(self.invoke('WIPICKnlInterface','get_resource',handle,buffer,len(expected)-1),0xffffffff)
        self.assertEqual(self.invoke('WIPICKnlInterface','get_resource',handle,buffer,len(expected)),0)
        self.assertEqual(bytes(self.p.uc.mem_read(self.p.words(buffer)[0]+8,len(expected))),expected)
    def test_memory_only_save_and_reopen(self):
        name=self.string('prefs');data=self.string('test')
        self.assertEqual(self.invoke('WIPICFsInterface','open',name,1,1),0xfffffff4)
        fd=self.invoke('WIPICFsInterface','open',name,4,1)
        self.assertEqual(self.invoke('WIPICFsInterface','write',fd,data,4),4)
        self.invoke('WIPICFsInterface','close',fd)
        fd=self.invoke('WIPICFsInterface','open',name,1,1);out=self.p.alloc(4)
        self.assertEqual(self.invoke('WIPICFsInterface','read',fd,out,8),4)
        self.assertEqual(bytes(self.p.uc.mem_read(out,4)),b'test')
        self.assertEqual(self.invoke('WIPICFsInterface','read',fd,out,4),0xffffffe9)
    def test_timer_and_unknown_service(self):
        timer=self.p.alloc(4)
        self.invoke('WIPICKnlInterface','def_timer',timer,0x1103fd)
        self.assertEqual(self.invoke('WIPICKnlInterface','set_timer',timer,10,0,123),0)
        self.assertEqual(self.invoke('WIPICKnlInterface','set_timer',timer,10,0,123),0xfffffffb)
        self.assertEqual(len(self.p.pending),1)
        self.invoke('WIPICKnlInterface','unset_timer',timer);self.assertFalse(self.p.pending)
        self.invoke('WIPICGraphicsInterface','not_implemented')
        self.assertIn('not_implemented',self.p.halted)
    def test_wdi_truncation_rejected(self):
        data=self.p.resources['24.wdi'];result=inspect('24.wdi',data)
        self.assertEqual((result['width'],result['height']),(136,22))
        with self.assertRaises(ValueError):inspect('24.wdi',data[:-1])
    def test_overlapping_framebuffer_copy(self):
        fb=self.p.framebuffer(3,3);pixels=self.p.fb(fb)[3]
        self.p.uc.mem_write(pixels,struct.pack('<9H',*range(1,10)))
        stack=self.p.uc.reg_read(UC_ARM_REG_SP);self.p.write(stack,2,0,0,0,0)
        self.invoke('WIPICGraphicsInterface','copy_area',fb,0,1,3)
        self.assertEqual(struct.unpack('<9H',bytes(self.p.uc.mem_read(pixels,18))),(1,2,3,1,2,3,4,5,6))

if __name__=='__main__':unittest.main()
