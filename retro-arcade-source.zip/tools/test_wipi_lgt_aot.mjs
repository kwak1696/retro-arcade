import fs from 'node:fs';
import assert from 'node:assert/strict';
import install from '../analysis/wipi/aot/nom3-code.mjs';
import {LgtRuntime} from '../src/wipi-lgt-runtime.mjs';
const seed=JSON.parse(fs.readFileSync(new URL('../analysis/wipi/aot/nom3-seed.json',import.meta.url)));
const m=new LgtRuntime(seed);install(m);m.initialize();m.start();m.repaintRequested=true;let time=1000;
// Match the browser: only game-requested repaints, including the post-collision path.
const ticks=n=>{for(let i=0;i<n;i++){time+=50;m.advance(time);}};
ticks(400);
for(let k=0;k<14;k++){
 m.call(m.u32(m.u32(m.card)+26*4),[m.card,1,0xfffffffb]);
 m.call(m.u32(m.u32(m.card)+26*4),[m.card,2,0xfffffffb]);ticks(40);
 fs.writeFileSync(new URL(`../analysis/wipi/aot/nom3-play-${k}.rgba`,import.meta.url),m.screenImage.data);
}
// Previously this failed 86 ticks after entering play on Calendar.get(HOUR_OF_DAY).
ticks(1200);
assert(m.frames>=1000);assert(m.card);assert(m.screenImage.data.some(x=>x!==255));
const calendar=m.service('java|java/util/Calendar|getInstance|()Ljava/util/Calendar;',[]);
m.objects.get(calendar).date=new Date(2026,9,29,23,58,57,123);
for(const [field,expected] of [[1,2026],[2,9],[5,29],[7,5],[9,1],[10,11],[11,23],[12,58],[13,57],[14,123]])assert.equal(m.service('java|java/util/Calendar|get|(I)I',[calendar,field]),expected);
// Preserve save files across a new runtime, just as a browser reload does.
const saved=new Map([...m.files].map(([name,data])=>['nom3:file:'+name,JSON.stringify([...data])]));
const storage={getItem:key=>saved.get(key)||null,setItem:(key,value)=>saved.set(key,value)};
const restored=new LgtRuntime(JSON.parse(fs.readFileSync(new URL('../analysis/wipi/aot/nom3-seed.json',import.meta.url))),{storage});
install(restored);restored.initialize();restored.start();restored.repaintRequested=true;
// Exercise sub-50ms display ticks as well as the 50ms scenario above.
for(let i=0;i<120;i++)restored.advance(1000+i*1000/60);
assert(restored.frames>0);
assert.deepEqual(restored.files.get('/nom'),m.files.get('/nom'));
const result={frames:m.frames,heap:m.cursor-0x4000000,files:Object.fromEntries([...m.files].map(([name,data])=>[name,data.length]))};
fs.writeFileSync(new URL('../analysis/wipi/aot/nom3-validation.json',import.meta.url),JSON.stringify(result,null,2));
console.log('NOM3 compiled JavaScript validation:',result);
