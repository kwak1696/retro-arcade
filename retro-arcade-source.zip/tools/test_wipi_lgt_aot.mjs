import fs from 'node:fs';
import assert from 'node:assert/strict';
import install from '../analysis/wipi/aot/nom3-code.mjs';
import {LgtRuntime} from '../src/wipi-lgt-runtime.mjs';
const seed=JSON.parse(fs.readFileSync(new URL('../analysis/wipi/aot/nom3-seed.json',import.meta.url)));
const m=new LgtRuntime(seed);install(m);m.initialize();m.start();let time=1000;
const ticks=n=>{for(let i=0;i<n;i++){time+=50;m.repaintRequested=true;m.advance(time);}};
ticks(400);
for(let k=0;k<14;k++){
 m.call(m.u32(m.u32(m.card)+26*4),[m.card,1,0xfffffffb]);
 m.call(m.u32(m.u32(m.card)+26*4),[m.card,2,0xfffffffb]);ticks(40);
 fs.writeFileSync(new URL(`../analysis/wipi/aot/nom3-play-${k}.rgba`,import.meta.url),m.screenImage.data);
}
assert(m.frames>=800);assert(m.card);assert(m.screenImage.data.some(x=>x!==255));
const result={frames:m.frames,heap:m.cursor-0x4000000,files:Object.fromEntries([...m.files].map(([name,data])=>[name,data.length]))};
fs.writeFileSync(new URL('../analysis/wipi/aot/nom3-validation.json',import.meta.url),JSON.stringify(result,null,2));
console.log('NOM3 compiled JavaScript validation:',result);
