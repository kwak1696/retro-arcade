param([string]$JavaHome = $env:JAVA_HOME, [string]$MavenExe = '')
$ErrorActionPreference = 'Stop'
$projectPath = Split-Path $PSScriptRoot -Parent
Push-Location $projectPath
try {
    if (-not $JavaHome) { $JavaHome = (Get-ChildItem -LiteralPath "$projectPath\analysis\jdk" -Directory | Select-Object -First 1).FullName }
    if (-not $JavaHome) { throw 'Set JAVA_HOME to a JDK 17+ installation.' }
    $env:JAVA_HOME = $JavaHome
    if (-not $MavenExe) {
        $mavenCommand = Get-Command mvn -ErrorAction SilentlyContinue
        if ($mavenCommand) { $MavenExe = $mavenCommand.Source }
        else { $MavenExe = "$projectPath\analysis\maven\apache-maven-3.9.11\bin\mvn.cmd" }
    }
    & $MavenExe -B dependency:go-offline
    if ($LASTEXITCODE -ne 0) { throw 'Dependency download failed.' }
    $asmPath = Join-Path $env:USERPROFILE '.m2\repository\org\ow2\asm\asm\9.7.1\asm-9.7.1.jar'
    & "$JavaHome\bin\javac.exe" -cp $asmPath tools/PatchJar.java
    if ($LASTEXITCODE -ne 0) { throw 'JAR normalizer compilation failed.' }
    & "$JavaHome\bin\java.exe" -cp "tools;$asmPath" PatchJar lib/NOM.jar lib/NOM-web.jar
    if ($LASTEXITCODE -ne 0) { throw 'JAR normalization failed.' }
    & "$JavaHome\bin\java.exe" -cp "tools;$asmPath" PatchJar lib/NOM2.jar lib/NOM2-web.jar
    if ($LASTEXITCODE -ne 0) { throw 'NOM 2 JAR normalization failed.' }
    python tools/resources.py
    if ($LASTEXITCODE -ne 0) { throw 'Resource preparation failed.' }
    & $MavenExe -B package
    if ($LASTEXITCODE -ne 0) { throw 'ECMAScript compilation failed.' }
    & $MavenExe -B package '-Dnom.jar=NOM2-web.jar' '-Dnom.entry=Boot2' '-Dnom.script=nom2.js' '-Dnom.exclude=Boot.java'
    if ($LASTEXITCODE -ne 0) { throw 'NOM 2 ECMAScript compilation failed.' }
} finally { Pop-Location }
