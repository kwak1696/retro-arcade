import java.nio.file.*;import java.util.jar.*;import java.io.*;import org.objectweb.asm.*;
/** Build-only normalization: JVM permits fields distinguished only by descriptor; TeaVM does not. */
public class PatchJar {
 static String field(String name,String desc){return name+"_"+Integer.toHexString(desc.hashCode());}
 public static void main(String[] args)throws Exception{
  try(JarInputStream in=new JarInputStream(Files.newInputStream(Path.of(args[0])));JarOutputStream out=new JarOutputStream(Files.newOutputStream(Path.of(args[1])))){
   JarEntry e;while((e=in.getNextJarEntry())!=null){byte[] data=in.readAllBytes();if(e.getName().endsWith(".class")){
    ClassWriter cw=new ClassWriter(0);new ClassReader(data).accept(new ClassVisitor(Opcodes.ASM9,cw){
     public FieldVisitor visitField(int a,String n,String d,String s,Object v){return super.visitField(a,field(n,d),d,s,v);}
     public MethodVisitor visitMethod(int a,String n,String d,String s,String[] ex){return new MethodVisitor(Opcodes.ASM9,super.visitMethod(a,n,d,s,ex)){
      public void visitFieldInsn(int op,String owner,String n,String d){super.visitFieldInsn(op,owner,!owner.startsWith("java/")&&!owner.startsWith("javax/")?field(n,d):n,d);}
      public void visitMethodInsn(int op,String owner,String n,String d,boolean it){
       if(owner.equals("java/lang/Class")&&n.equals("getResourceAsStream")){super.visitMethodInsn(Opcodes.INVOKESTATIC,"nom/Resources","open","(Ljava/lang/Class;Ljava/lang/String;)Ljava/io/InputStream;",false);}
       else if(owner.equals("java/lang/System")&&n.equals("getProperty")&&d.equals("(Ljava/lang/String;)Ljava/lang/String;")){super.visitMethodInsn(Opcodes.INVOKESTATIC,"nom/Resources","property",d,false);}
       else super.visitMethodInsn(op,owner,n,d,it);
      }
     };}
    },0);data=cw.toByteArray();
   }out.putNextEntry(new JarEntry(e.getName()));out.write(data);out.closeEntry();}
  }
 }
}
