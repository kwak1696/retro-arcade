package nom;
import org.teavm.jso.*;
import org.teavm.interop.Async;
import org.teavm.interop.AsyncCallback;
public class Bridge {
    @JSFunctor public interface ImageDone extends JSObject { void done(JSObject image); }
    @Async public static native JSObject decode(byte[] bytes);
    private static void decode(byte[] bytes, AsyncCallback<JSObject> callback) { decodeNative(bytes, callback::complete); }
    @JSBody(params={"bytes","done"},script="window.nomHost.decode(bytes,done);")
    private static native void decodeNative(@JSByRef byte[] bytes,ImageDone done);
    @JSBody(params={"w","h"},script="var c=document.createElement('canvas');c.width=w;c.height=h;c.getContext('2d').fillStyle='#fff';c.getContext('2d').fillRect(0,0,w,h);return c;")
    public static native JSObject image(int w,int h);
    @JSBody(script="return document.getElementById('game');") public static native JSObject screen();
    @JSBody(params="im",script="return im.width;") public static native int width(JSObject im);
    @JSBody(params="im",script="return im.height;") public static native int height(JSObject im);
    @JSBody(params={"im","x","y","w","h","out","off","stride"},script="var d=im.getContext('2d').getImageData(x,y,w,h).data;for(var j=0;j<h;j++)for(var i=0;i<w;i++){var k=(j*w+i)*4;out[off+j*stride+i]=(d[k+3]<<24)|(d[k]<<16)|(d[k+1]<<8)|d[k+2];}")
    public static native void rgb(JSObject im,int x,int y,int w,int h,@JSByRef int[] out,int off,int stride);
    @JSBody(params={"im","x","y","w","h"},script="var c=im.getContext('2d');if(c._saved)c.restore();c.save();c._saved=true;c.beginPath();c.rect(x,y,Math.max(0,w),Math.max(0,h));c.clip();c.imageSmoothingEnabled=false;")
    public static native void clip(JSObject im,int x,int y,int w,int h);
    @JSBody(params={"im","color","x","y","w","h","outline"},script="var c=im.getContext('2d');c.fillStyle=c.strokeStyle='#'+(color>>>0).toString(16).padStart(6,'0').slice(-6);if(outline)c.strokeRect(x+.5,y+.5,w,h);else c.fillRect(x,y,w,h);")
    public static native void rect(JSObject im,int color,int x,int y,int w,int h,boolean outline);
    @JSBody(params={"im","color","x","y","x2","y2"},script="var c=im.getContext('2d');c.strokeStyle='#'+(color>>>0).toString(16).padStart(6,'0').slice(-6);c.beginPath();c.moveTo(x+.5,y+.5);c.lineTo(x2+.5,y2+.5);c.stroke();")
    public static native void line(JSObject im,int color,int x,int y,int x2,int y2);
    @JSBody(params={"dst","src","sx","sy","w","h","transform","x","y"},script="window.nomHost.draw(dst,src,sx,sy,w,h,transform,x,y);")
    public static native void draw(JSObject dst,JSObject src,int sx,int sy,int w,int h,int transform,int x,int y);
    @JSBody(params={"im","s","x","y","color"},script="var c=im.getContext('2d');c.font='10px monospace';c.textBaseline='top';c.fillStyle='#'+(color>>>0).toString(16).padStart(6,'0').slice(-6);c.fillText(s,x,y);")
    public static native void text(JSObject im,String s,int x,int y,int color);
    @JSBody(params={"key"},script="return localStorage.getItem((window.nomHost.storagePrefix || 'nom-native:')+key);") public static native String load(String key);
    @JSBody(params={"key","value"},script="localStorage.setItem((window.nomHost.storagePrefix || 'nom-native:')+key,value);") public static native void save(String key,String value);
    @JSBody(params={"bytes","kind"},script="return window.nomHost.audio(bytes,kind);") public static native JSObject audio(@JSByRef byte[] bytes,String kind);
    @JSBody(params={"audio","loop","volume"},script="window.nomHost.play(audio,loop,volume);") public static native void play(JSObject audio,boolean loop,int volume);
    @JSBody(params={"audio"},script="if(audio)audio.pause();") public static native void stop(JSObject audio);
}
