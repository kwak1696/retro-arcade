package nom;
import java.io.*;import java.util.Base64;import org.teavm.jso.JSBody;
public class Resources {
 @JSBody(params="name",script="return window.nomHost.resources[name.replace(/^\\//,'')] || null;") private static native String data(String name);
 public static InputStream open(Class<?> type,String name){String s=data(name);return s==null?null:new ByteArrayInputStream(Base64.getDecoder().decode(s));}
 public static String property(String key){if(key.equals("microedition.locale"))return "en";if(key.equals("microedition.platform"))return "Nokia";if(key.equals("microedition.encoding"))return "ISO-8859-1";return System.getProperty(key);}
}
