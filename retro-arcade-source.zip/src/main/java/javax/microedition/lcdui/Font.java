package javax.microedition.lcdui;
public class Font {public static Font getFont(int face,int style,int size){return new Font();} public static Font getDefaultFont(){return new Font();}public int getFace(){return 0;}public int getSize(){return 8;}public int getHeight(){return 12;} public int charWidth(char c){return 6;} public int stringWidth(String s){return s.length()*6;}}
