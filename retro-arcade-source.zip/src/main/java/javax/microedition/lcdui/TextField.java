package javax.microedition.lcdui;public class TextField extends Item {public TextField(String label,String value,int size,int constraints){text=value;}public String getString(){return text;}}
