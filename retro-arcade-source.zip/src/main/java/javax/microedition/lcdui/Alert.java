package javax.microedition.lcdui;public class Alert extends Form {public Alert(String t,String s,Image i,AlertType type){super(t);append(s);}public void setTimeout(int time){}}
