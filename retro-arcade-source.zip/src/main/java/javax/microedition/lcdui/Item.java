package javax.microedition.lcdui;public class Item {public String text="";public String toString(){return text;}}
