package javax.microedition.lcdui;
public class Displayable {
 protected java.util.List<Command> commands=new java.util.ArrayList<>();protected CommandListener listener;protected String title="";
 public void addCommand(Command command){commands.add(command);}public void setCommandListener(CommandListener l){listener=l;}public void setTitle(String title){this.title=title;}
 public int getWidth(){return nom.Bridge.width(nom.Bridge.screen());} public int getHeight(){return nom.Bridge.height(nom.Bridge.screen());} public boolean isShown(){return true;}
}
