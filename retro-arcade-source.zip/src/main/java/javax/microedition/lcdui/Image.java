package javax.microedition.lcdui;
import nom.Bridge;import org.teavm.jso.JSObject;import java.io.*;
public class Image {
 final JSObject canvas; private Graphics graphics;
 private Image(JSObject canvas){this.canvas=canvas;}
 public static Image createImage(int w,int h){return new Image(Bridge.image(w,h));}
 public static Image createImage(byte[] bytes,int off,int len){byte[] data=new byte[len];System.arraycopy(bytes,off,data,0,len);return new Image(Bridge.decode(data));}
 public static Image createImage(String name) throws IOException {try(InputStream in=nom.Resources.open(Image.class,name)){if(in==null)throw new IOException(name);ByteArrayOutputStream out=new ByteArrayOutputStream();int b;while((b=in.read())!=-1)out.write(b);return createImage(out.toByteArray(),0,out.size());}}
 public int getWidth(){return Bridge.width(canvas);}public int getHeight(){return Bridge.height(canvas);}public Graphics getGraphics(){if(graphics==null)graphics=new Graphics(canvas);return graphics;}
 public void getRGB(int[] out,int off,int stride,int x,int y,int w,int h){Bridge.rgb(canvas,x,y,w,h,out,off,stride);}
}
