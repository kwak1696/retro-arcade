package javax.microedition.lcdui;public class AlertType {public static final AlertType CONFIRMATION=new AlertType(),ERROR=new AlertType(),INFO=new AlertType(),WARNING=new AlertType();}

