package javax.microedition.lcdui;
import nom.Bridge;
public abstract class Canvas extends Displayable {
 public static Canvas active; private Graphics graphics;
 public Canvas(){active=this;} public void setFullScreenMode(boolean full){}
 protected abstract void paint(Graphics graphics); protected void keyPressed(int key){} protected void keyReleased(int key){}
 public void input(int key,boolean down){if(down)keyPressed(key);else keyReleased(key);}
 public int getGameAction(int key){switch(key){case -1:case 50:return 1;case -2:case 56:return 6;case -3:case 52:return 2;case -4:case 54:return 5;case -5:case 53:return 8;default:return 0;}}
 public void repaint(){} public void repaint(int x,int y,int w,int h){}
 public void serviceRepaints(){if(graphics==null)graphics=new Graphics(Bridge.screen());graphics.setClip(0,0,getWidth(),getHeight());paint(graphics);}
}
