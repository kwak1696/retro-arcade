package javax.microedition.lcdui;
public class Command {public String label;private int type;public Command(String s,int type,int priority){label=s;this.type=type;}public int getCommandType(){return type;}}
