package javax.microedition.lcdui;
import nom.Bridge;import org.teavm.jso.JSObject;
public class Graphics {
 private final JSObject canvas;private int color,x,y,w,h; private Font font=new Font();
 public Graphics(JSObject canvas){this.canvas=canvas;setClip(0,0,Bridge.width(canvas),Bridge.height(canvas));}
 public void setClip(int x,int y,int w,int h){this.x=x;this.y=y;this.w=Math.max(0,w);this.h=Math.max(0,h);Bridge.clip(canvas,x,y,w,h);}
 public int getClipX(){return x;}public int getClipY(){return y;}public int getClipWidth(){return w;}public int getClipHeight(){return h;}
 public void setColor(int c){color=c&0xffffff;}public void setColor(int r,int g,int b){setColor((r<<16)|(g<<8)|b);}public int getColor(){return color;}
 public void fillRect(int x,int y,int w,int h){Bridge.rect(canvas,color,x,y,w,h,false);}public void drawRect(int x,int y,int w,int h){Bridge.rect(canvas,color,x,y,w,h,true);}
 public void drawLine(int x,int y,int x2,int y2){Bridge.line(canvas,color,x,y,x2,y2);}public void setFont(Font f){font=f;}
 public void drawString(String s,int x,int y,int anchor){if((anchor&8)!=0)x-=font.stringWidth(s);else if((anchor&1)!=0)x-=font.stringWidth(s)/2;if((anchor&32)!=0)y-=font.getHeight();else if((anchor&2)!=0)y-=font.getHeight()/2;else if((anchor&64)!=0)y-=10;Bridge.text(canvas,s,x,y,color);}
 public void drawImage(Image im,int x,int y,int anchor){drawRegion(im,0,0,im.getWidth(),im.getHeight(),0,x,y,anchor);}
 public void drawRegion(Image im,int sx,int sy,int w,int h,int t,int x,int y,int a){int dw=t>=4?h:w,dh=t>=4?w:h;if((a&8)!=0)x-=dw;else if((a&1)!=0)x-=dw/2;if((a&32)!=0)y-=dh;else if((a&2)!=0)y-=dh/2;Bridge.draw(canvas,im.canvas,sx,sy,w,h,t,x,y);}
}
