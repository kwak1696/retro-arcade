package javax.microedition.lcdui;
import javax.microedition.midlet.MIDlet;
public class Display {
 private static final Display INSTANCE=new Display(); public static Display getDisplay(MIDlet m){return INSTANCE;}
 public void setCurrent(Displayable d){if(d instanceof Canvas){Canvas.active=(Canvas)d;if(d instanceof Form)((Canvas)d).serviceRepaints();}} public void setCurrent(Alert a,Displayable next){setCurrent(a);}public boolean vibrate(int ms){return false;}
}

