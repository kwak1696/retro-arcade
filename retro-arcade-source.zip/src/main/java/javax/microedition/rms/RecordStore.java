package javax.microedition.rms;
import nom.Bridge;import java.util.Base64;
public class RecordStore {
 private String name;public static RecordStore openRecordStore(String name,boolean create){RecordStore r=new RecordStore();r.name=name;return r;}
 public int getNumRecords(){String n=Bridge.load(name+":n");return n==null?0:Integer.parseInt(n);}
 public byte[] getRecord(int id)throws InvalidRecordIDException{String s=Bridge.load(name+":"+id);if(s==null)throw new InvalidRecordIDException();return Base64.getDecoder().decode(s);}
 public int addRecord(byte[] data,int off,int len){int id=getNumRecords()+1;setRecord(id,data,off,len);Bridge.save(name+":n",String.valueOf(id));return id;}
 public void setRecord(int id,byte[] data,int off,int len){byte[] copy=new byte[len];System.arraycopy(data,off,copy,0,len);Bridge.save(name+":"+id,Base64.getEncoder().encodeToString(copy));}
 public void closeRecordStore(){}
}
