package javax.microedition.media;public interface Controllable {Control getControl(String s);}
