package javax.microedition.media;
import java.io.*;import nom.Bridge;import org.teavm.jso.JSObject;import javax.microedition.media.control.VolumeControl;
public class Manager {
 public static Player createPlayer(InputStream in,String kind)throws IOException{ByteArrayOutputStream out=new ByteArrayOutputStream();int b;while((b=in.read())!=-1)out.write(b);return new BrowserPlayer(Bridge.audio(out.toByteArray(),kind));}
 static class BrowserPlayer implements Player,VolumeControl {JSObject audio;int loops=1,volume=70,state=100;BrowserPlayer(JSObject a){audio=a;}public void realize(){state=200;}public void prefetch(){state=300;}public void deallocate(){state=200;}public void addPlayerListener(PlayerListener l){}public void removePlayerListener(PlayerListener l){}public void close(){stop();state=0;}public void start(){state=400;Bridge.play(audio,loops<0,volume);}public void stop(){state=300;Bridge.stop(audio);}public void setLoopCount(int n){loops=n;}public Control getControl(String s){return this;}public int setLevel(int n){return volume=n;}public int getState(){return state;}public long setMediaTime(long t){return t;}}
}
