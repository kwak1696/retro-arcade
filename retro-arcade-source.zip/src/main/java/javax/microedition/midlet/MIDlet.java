package javax.microedition.midlet;
public abstract class MIDlet {
 public MIDlet(){} protected abstract void startApp(); protected abstract void pauseApp(); protected abstract void destroyApp(boolean unconditional);
 public String getAppProperty(String key){return property(key);}
 @org.teavm.jso.JSBody(params="key",script="return window.nomHost.properties[key] || null;") private static native String property(String key);
 public void notifyDestroyed(){} public boolean platformRequest(String url){return false;}
}
