import javax.microedition.lcdui.Canvas;
import org.teavm.jso.*;
public class Boot2 {
 @JSFunctor interface Key extends JSObject {void call(int key,boolean down);}
 @JSBody(params="key",script="window.nomHost.key=key;window.nomHost.ready=true;") private static native void bind(Key key);
 public static void main(String[] args){bind((key,down)->{Canvas c=Canvas.active;if(c!=null)c.input(key,down);});new Nom2().startApp();}
}
